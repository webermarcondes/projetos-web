var tot_despesa = 0;
var tot_receita = 0;
var tot_saldo = 0;

function adicionar() {

        let tr = document.createElement('tr');
        let td_conta = document.createElement('td');
        let td_tipo = document.createElement('td');
        let td_valor = document.createElement('td');


        let conta = document.getElementById('conta').value;
        let tipo = document.getElementById('tipo').value;
        let valor = document.getElementById('valor').value;

        td_conta.innerHTML = conta;

        if(tipo == 'D') {
            td_tipo.innerHTML = "Despesa";

            tot_despesa += parseInt(valor)
            document.getElementById('tot_despesa').innerHTML = tot_despesa;
        }
        else {
            td_tipo.innerHTML = "Receita";

            tot_receita += parseInt(valor);
            document.getElementById('tot_receita').innerHTML = tot_receita;
        }
        

        tot_saldo = (tot_receita - tot_despesa);

        if(tot_saldo < 0) {
            document.getElementById('saldo').style.backgroundColor = 'red';
        }

        else if(tot_saldo > 0) {
            document.getElementById('saldo').style.backgroundColor = 'blue';
        }

        else {
            document.getElementById('saldo').style.backgroundColor = 'white';
        }


        document.getElementById('tot_saldo').innerHTML = tot_saldo;

        td_valor.innerHTML = valor;

        td_conta.align = "center";
        td_tipo.align = "center";
        td_valor.align = "right";

        tr.append(td_conta);
        tr.append(td_tipo);
        tr.append(td_valor);


        document.getElementsByTagName('table')[0].append(tr);
}