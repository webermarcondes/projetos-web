window.onload = function(){

    document.getElementsByTagName('p')[1].style.marginBottom = '50px'; //propriedades CSS definidas por JS por padrão
                                                                       // são consideradas INLINE;
    





                                                                       
}